<h1> Alex-SAVIYA-Whatsapp-Userbot </h1>

----

<div align="center">
  <img src="https://telegra.ph/file/fdc00d3f0742f604a6a6d.jpg" width="200" height="200">
  <h1>🐺ALEX SAVIYA</h1>
</div>
<p align="center">
    ALEX SAVIYA project - Makes it easy and fun to use Whatsapp. Also first userbot for Whatsapp
    <br>
        Reserved |
        Reserved |
        <a href="https://t.me/Saviya_Infinity_bot">Telegram Channel</a> |
        <a href="https://t.me/Saviya_Infinity_Chat">Telegram Group</a> |
    <br>
</p>

----
![Docker Pulls](https://img.shields.io/docker/pulls/fusuf/whatsasena?style=flat-square) ![Docker Image Size (latest by date)](https://img.shields.io/docker/image-size/fusuf/whatsasena?style=flat-square)

## 📢 Guide
> [Also for support & help please come our Telegram group.](https://t.me/Saviya_Infinity_Chat)

> [Install Guide/Kurulum Yardımcısı/Qurulum Müavin](https://github.com/SAVIYA-OFFICIAL/Alex-SAVIYA-Whatsapp-Userbot/wiki)

> [Video Guide](https://youtu.be/gPKWNb5YTfQ)

> [You can translate other languages from Crowdin](https://crowdin.com/project/whatsasena)

## 🔎 What is ALEX SAVIYA?
**ALEX SAVIYA,** is a WhatsApp helper bot written by [Yusuf Usta](https://github.com/Quiec). Does not log into your account It is written on WhatsApp Web API.

## Setup
### Very Simple Method
`We are working on it...`

### Simple Method
[![Run on Repl.it](https://repl.it/badge/github/SAVIYA-OFFICIAL/Alex-SAVIYA-Whatsapp-Userbot)](https://replit.com/@SAVIYA-OFFICIAL/Alex-SAVIYA-Whatsapp-Userbot-1?v=1)

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/SAVIYA-OFFICIAL/Alex-SAVIYA-Whatsapp-Userbot)

### The Hard Method
```js
git clone https://github.com/SAVIYA-OFFICIAL/Alex-SAVIYA-Whatsapp-Userbot/.git
cd Alex SAVIYA
npm i
# Config.env oluşturun ve düzenleyin. #
# Config.env create and edit. #
node bot.js
```

## F.A.Q
Answer a few frequently asked questions;
### Can you read my messages?
This project is open source so all the codes are clear. Neither less nor more; you can look what you want. **We absolutely do not have access to your accounts.**

### What about our security?
If you are concerned about security, you can install it on your own computer. If you think someone else has captured your data, simply click on **Whatsapp> Three Dots> Whatsapp Web> Logout** from all sessions button.

### Is it paid?
**Of course not.** It will never happen. But you can donate to us. You can reach me via [Telegram](https://t.me/Saviya_Infinity_bot) .

### What does Asena mean?
[Asena](https://tr.wikipedia.org/wiki/Asena), comes from Turkish mythology. According to Turkish mythology, Asena is a she-wolf that plays an important role.

### ⚠️ Warning! 
```
Due to Userbot; Your WhatsApp account may be banned.
This is an open source project, you are responsible for everything you do. 
Absolutely, Asena executives do not accept responsibility.
By establishing the Asena, you are deemed to have accepted these responsibilities.
```

## Developer


[SAVIYA](https://t.me/SAVIYA_OFFICIAL) | [Chanel](https://t.me/Saviya_Infinity_bot) | [Group](https://t.me/Saviya_Infinity_Chat) | [SAVIYA OFFICIAL](https://github.com/SAVIYA-OFFICIAL)  | [SHAPORT](https://t.me/Saviyaofficialyoutube)


## License
This project is protected by `GNU General Public Licence v3.0` license.

### Disclaimer
`WhatsApp` name, its variations and the logo are registered trademarks of Facebook. We have nothing to do with the registered trademark
